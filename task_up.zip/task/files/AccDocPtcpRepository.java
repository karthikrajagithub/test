/*
 * +=============================================================================================+
 * |                                                                                             |
 * |                                Copyright (C) 2016-2018                                      |
 * |                                 Nomura Holdings, Inc.                                       |
 * |                                  All Rights Reserved                                        |
 * |                                                                                             |
 * |  This document is the sole property of Nomura Holdings, Inc.                                |
 * |  No part of this document may be reproduced in any form or by any                           |
 * |  means - electronic, mechanical, photocopying, recording or otherwise - without the prior   |
 * |  written permission of Nomura Holdings, Inc.                                                |
 * |                                                                                             |
 * |  Unless required by applicable law or agreed to in writing, software distributed under      |
 * |  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF        |
 * |  ANY KIND, either express or implied.                                                       |
 * |                                                                                             |
 * +=============================================================================================+
 */
package com.nri.dmm.domain.repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.nri.dmm.DmmConstants;
import com.nri.dmm.domain.entity.AccountDocPtcp;
import com.nri.dmm.domain.entity.AccountDocument;
import com.nri.dmm.domain.entity.AccountInfo;
import com.nrift.finch.Globals;
import com.nrift.finch.inf.db.DbUtils;
import com.nrift.finch.inf.domain.repository.RepositoryBase;
import com.nrift.finch.inf.exception.FinchException;

@Repository
public class AccDocPtcpRepository extends RepositoryBase<AccountDocPtcp, Long> {

	private static final Logger	log			= LoggerFactory.getLogger(AccountInfoRepository.class);

	public static final int		MAX_VALUE	= 1;

	@PersistenceContext(unitName = "dmm-em")
	private EntityManager		em;

	@Override
	public EntityManager getEntityManager() {
		return em;
	}

	/**
	 * Method to find the list of documents for LCP,CCP whose waterfall flag as "Y"
	 * 
	 * @param accInfoPk
	 * @return DocumentList
	 */
	public List<AccountDocPtcp> findWaterfallDocs(Long accInfoPk) {

		List<AccountDocPtcp> doclist = new ArrayList<AccountDocPtcp>();
		String ql = "select d from AccountDocPtcp d where d.dmmAccountInfoByAccountInfoPk.accountInfoPk=:accInfoPk " + " and d.status=:status "
				+ " and d.dmmAccountDocument.status=:status" + " and d.dmmAccountDocument.waterfallFlag=:flag ";
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accInfoPk", accInfoPk);
		q.setParameter("flag", DmmConstants.YES);
		q.setParameter("status", Globals.NORMAL_STATUS);
		doclist = q.getResultList();
		return doclist;

	}

	/**
	 * Method to find the list of documents for an accounts
	 * 
	 * @param accInfoPk
	 * @return DocumentList
	 */
	public List<AccountDocPtcp> findDocListByPk(Long accInfoPk) {

		List<AccountDocPtcp> doclist = new ArrayList<AccountDocPtcp>();
		String ql = "select d from AccountDocPtcp d where d.dmmAccountInfoByAccountInfoPk.accountInfoPk=:accInfoPk" + " and d.status=:status "
				+ " and (d.associationApprovedStatus = '" + DmmConstants.APPROVED + "' " + " OR d.associationApprovedStatus IS NULL) "
				+ " and d.dmmAccountDocument.status=:accountDocStatus ";
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accInfoPk", accInfoPk);
		q.setParameter("status", Globals.NORMAL_STATUS);
		q.setParameter("accountDocStatus", Globals.NORMAL_STATUS);
		doclist = q.getResultList();
		return doclist;

	}

	/**
	 * Method to find the list of documents to cancel for the existing LCP, CCP records
	 * 
	 * @param accInfoPk
	 * @param hierarchicalLevel
	 * @return DocumentList
	 */
	public List<AccountDocPtcp> findDocsToCancel(Long accInfoPk, String hierarchicalLevel) {

		List<AccountDocPtcp> doclist = new ArrayList<AccountDocPtcp>();
		String ql = "select d from AccountDocPtcp d where d.dmmAccountInfoByAccountInfoPk.accountInfoPk=:accInfoPk"
				+ " and d.inheritedFrom=:hierarchicalLevel" + " and d.status=:status " + " and d.inheritedFlag=:inheritFlag ";
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accInfoPk", accInfoPk);
		q.setParameter("hierarchicalLevel", hierarchicalLevel);
		q.setParameter("inheritFlag", DmmConstants.WATERFALL);
		q.setParameter("status", Globals.NORMAL_STATUS);
		doclist = q.getResultList();
		return doclist;

	}

	/**
	 * Method to write Account Document PTCP record to database
	 * 
	 * @param accountDocPtcp
	 * @throws FinchException
	 */
	public void saveDmmAccountDocPtcp(AccountDocPtcp accountDocPtcp) throws FinchException {
		write(accountDocPtcp);
		getEntityManager().flush();
	}

	/**
	 * Method to update List of Account Document PTCP record to database
	 * 
	 * @param accountDocPtcp
	 * @throws FinchException
	 */
	public void updateDmmAccountDocPtcp(List<AccountDocPtcp> accountDocPtcp) throws FinchException {
		for (AccountDocPtcp accountDocPtcpAll : accountDocPtcp) {
			getEntityManager().merge(accountDocPtcpAll);
		}
		getEntityManager().flush();
	}
	
	/**
	 * Method to write List of Account Document PTCP record to database
	 * 
	 * @param accountDocPtcp
	 * @throws FinchException
	 */
	public void saveDmmAccountDocPtcp(List<AccountDocPtcp> accountDocPtcp) throws FinchException {
		for (AccountDocPtcp accountDocPtcpAll : accountDocPtcp) {
			getEntityManager().persist(accountDocPtcpAll);
		}
		getEntityManager().flush();
	}

	/**
	 * Method to CANCEL Account Document PTCP
	 * 
	 * @param accountDocPtcp
	 * @throws FinchException
	 */
	public void cancelAccDocPTCP(AccountDocPtcp accountDocPtcp) throws FinchException {
		accountDocPtcp.setStatus(Globals.CANCEL_STATUS);
		update(accountDocPtcp);
	}

	/**
	 * Method to find parent Account Document PTCP list from account document pk.
	 * 
	 * @param accountDocumentPk
	 * @return
	 */
	public List<AccountDocPtcp> getAccountDocPtcpByInheritedAccountInfoPk(long accountDocumentPk) {
		String ql = "SELECT ptcp FROM AccountDocPtcp ptcp WHERE ptcp.inheritedFlag = " + DbUtils.enquoteString(DmmConstants.WATERFALL)
				+ " AND ptcp.dmmAccountDocument.accountDocumentPk=:accDocPk  AND ptcp.status = " + DbUtils.enquoteString(Globals.NORMAL_STATUS)
				+ " AND ptcp.dmmAccountDocument.status = " + DbUtils.enquoteString(Globals.NORMAL_STATUS);
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accDocPk", accountDocumentPk);
		try {
			return q.getResultList();
		}
		catch (NoResultException nre) {
			log.info("No Account Document PTCP List is returned for the given query : [" + ql + "]", nre);
			return null;
		}
	}

	/**
	 * Method to find Account Document PTCP list from account document pk.
	 * 
	 * @param accPk
	 *            - Account Info pk
	 * @return
	 */
	public List<Long> getAccountDocPtcpByAccountInfoPk(long accPk) {
		String ql = "SELECT ptcp.accountDocPtcpPk FROM AccountDocPtcp ptcp WHERE ptcp.dmmAccountInfoByAccountInfoPk.accountInfoPk=:accPk "
				+ " AND (ptcp.associationApprovedStatus <> '" + DmmConstants.REJECTED + "' " + " OR ptcp.associationApprovedStatus IS NULL) "
				+ " AND ptcp.dmmAccountDocument.status = '" + DmmConstants.NORMAL + "' " + " AND ptcp.status = '" + DmmConstants.NORMAL + "' ";
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accPk", accPk);
		try {
			return q.getResultList();
		}
		catch (NoResultException nre) {
			log.info("No Account Document PTCP List is returned for the given query : [" + ql + "]", nre);
			return null;
		}
	}

	/**
	 * Method to get associated or waterfalled list
	 * 
	 * @param accDocPk
	 * @return
	 */
	public List<AccountDocPtcp> getAssociatedOrWaterfalledListByAccDocPk(long accDocPk) {
		String ql = "SELECT ptcp FROM AccountDocPtcp ptcp WHERE ptcp.dmmAccountDocument.accountDocumentPk=:accDocPk "
				+ " AND (ptcp.associationApprovedStatus = " + DbUtils.enquoteString(DmmConstants.APPROVED)
				+ " OR ptcp.associationApprovedStatus IS NULL)"
				+ " AND ptcp.inheritedFlag IS NOT NULL " + " AND ptcp.dmmAccountDocument.status = "
				+ DbUtils.enquoteString(Globals.NORMAL_STATUS) + " AND ptcp.status = " + DbUtils.enquoteString(Globals.NORMAL_STATUS);

		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accDocPk", accDocPk);
		try {
			return q.getResultList();
		}
		catch (NoResultException nre) {
			log.info("No Account Document PTCP List is returned for the given query : [" + ql + "]", nre);
			return null;
		}
	}

	/**
	 * Method to find list Account Info from given account document pk.
	 * 
	 * @param accPk
	 *            - Account Info pk
	 * @return
	 */
	public List<AccountInfo> getAccountInfoByAccDocPk(long accDocPk) {
		String ql = "SELECT ptcp.dmmAccountInfoByAccountInfoPk FROM AccountDocPtcp ptcp WHERE ptcp.dmmAccountDocument.accountDocumentPk=:accDocPk "
				+ " AND ptcp.status = '" + Globals.NORMAL_STATUS + "' " + " AND ptcp.dmmAccountInfoByAccountInfoPk.status = '"
				+ Globals.NORMAL_STATUS + "' ";
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accDocPk", accDocPk);
		try {
			return q.getResultList();
		}
		catch (Exception nre) {
			log.info("No Account Info List is returned for the given query : [" + ql + "]", nre);
			return null;
		}
	}

	/**
	 * Method to get Account Document List of waterfalled document
	 * 
	 * @param accInfoPk
	 * @param purposePk
	 * @return
	 */
	public List<AccountDocument> getSamePurposeAccDocList(long accInfoPk, long purposePk) {
		String ql = "SELECT ptcp.dmmAccountDocument FROM AccountDocPtcp ptcp WHERE ptcp.dmmAccountInfoByAccountInfoPk.accountInfoPk=:accInfoPk "
				+ " AND ptcp.status= " + DbUtils.enquoteString(Globals.NORMAL_STATUS) + " AND ptcp.dmmAccountInfoByAccountInfoPk.status= "
				+ DbUtils.enquoteString(Globals.NORMAL_STATUS) + " AND ptcp.dmmAccountDocument.documentStatus<> "
				+ DbUtils.enquoteString(DmmConstants.ACTIVE)
				+ " AND ptcp.dmmAccountDocument.dmmDocumentType.dmmDocumentPurpose.documentPurposePk=:purposePk";
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accInfoPk", accInfoPk);
		q.setParameter("purposePk", purposePk);
		try {
			return q.getResultList();
		}
		catch (Exception nre) {
			log.info("No Account Document List is returned for the given query : [" + ql + "]", nre);
			return null;
		}
	}

	/**
	 * Method to get Account Document List from Account Info Pk
	 * 
	 * @param accInfoPk
	 * @return
	 */
	public List<AccountDocument> getAccDocListByAccInfoPk(long accInfoPk) {
		String ql = "SELECT ptcp.dmmAccountDocument FROM AccountDocPtcp ptcp WHERE ptcp.dmmAccountInfoByAccountInfoPk.accountInfoPk=:accInfoPk "
				+ " AND ptcp.status= " + DbUtils.enquoteString(Globals.NORMAL_STATUS) + " AND ptcp.dmmAccountInfoByAccountInfoPk.status= "
				+ DbUtils.enquoteString(Globals.NORMAL_STATUS) + " AND ptcp.dmmAccountDocument.status= "
				+ DbUtils.enquoteString(Globals.NORMAL_STATUS) + " AND ptcp.dmmAccountDocument.documentApprovedStatus= "
				+ DbUtils.enquoteString(DmmConstants.APPROVED) + " AND (ptcp.associationApprovedStatus = "
				+ DbUtils.enquoteString(DmmConstants.APPROVED) + " OR ptcp.associationApprovedStatus IS NULL)"
				+ "AND ptcp.dmmAccountInfoByAccountInfoPk.neamFlag= " + DbUtils.enquoteString(Globals.DATABASE_NO);
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accInfoPk", accInfoPk);
		try {
			return q.getResultList();
		}
		catch (Exception nre) {
			log.info("No Account Document List is returned for the given query : [" + ql + "]", nre);
			return null;
		}
	}
	/**
	 * Method to find Account Document PTCP List
	 * 
	 * @param hierarchicalLevel
	 * @param rdmId
	 * @param accDocPk
	 * @return
	 */
	public List<AccountDocPtcp> findAccDocumentPtcpDetailsList(String hierarchicalLevel, BigInteger rdmId, long accDocPk) {
		String ql = "SELECT ptcp FROM AccountDocPtcp ptcp WHERE ptcp.dmmAccountDocument.accountDocumentPk=:accDocPk "
				+ " AND ptcp.dmmAccountInfoByAccountInfoPk.hierarchicalLevel=:hierLevel "
				+ " AND ptcp.dmmAccountInfoByAccountInfoPk.rdmId=:rdmId "
				+ " AND ptcp.dmmAccountInfoByAccountInfoPk.neamFlag=:nf "
				+ " ORDER BY ptcp.updateDate DESC " ;
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accDocPk", accDocPk);
		q.setParameter("hierLevel", hierarchicalLevel);
		q.setParameter("rdmId", rdmId);
		q.setParameter("nf", DmmConstants.NO);
		try {
			return q.getResultList();
		} catch (NoResultException nre) {
			log.info("No Account Document PTCP List is returned for the given query : [" + ql + "]", nre);
			return null;
		}
	}
	
	/**
	 * @param accInfoPk
	 * @param documentTypePk
	 * @return boolean value to indicate whether document is required or not
	 */
	public boolean isDocumentRequiredOnce(Long accInfoPk, Long documentTypePk) {
		String ql = "SELECT ptcp FROM AccountDocument doc," + " AccountDocPtcp ptcp,DocumentType ddt1"
				+ " WHERE ddt1.dmmDocumentPurpose.documentPurposePk = (SELECT ddt.dmmDocumentPurpose.documentPurposePk FROM DocumentType ddt"
				+ " WHERE ddt.documentTypePk =:documentTypePk AND ddt.status = " + DbUtils.enquoteString(Globals.NORMAL_STATUS) + ")"
				+ " AND doc.dmmAccountDocument.documentStatus IN(" + DbUtils.enquoteString(DmmConstants.ACTIVE) + ","
				+ DbUtils.enquoteString(DmmConstants.EXPIRED) + ")" + "	AND ptcp.inheritedFlag IS NULL" + "	AND ptcp.status          = "
				+ DbUtils.enquoteString(Globals.NORMAL_STATUS) /*+ "	AND doc.status           = " + DbUtils.enquoteString(Globals.NORMAL_STATUS)*/
				+ "	AND ddt1.status          = " + DbUtils.enquoteString(Globals.NORMAL_STATUS)
				+ " AND ptcp.dmmAccountInfoByAccountInfoPk.accountInfoPk =:accInfoPk;";
		System.out.println("Query:" + ql);
		Query q = getEntityManager().createQuery(ql);
		q.setParameter("accInfoPk", accInfoPk);
		q.setParameter("documentTypePk", documentTypePk);
		try {
			return (q.getResultList().size() > 0) ? false : true;
		}
		catch (NoResultException nre) {
			return true;
		}
	}
	
	}

