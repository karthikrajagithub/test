/*
 * +=============================================================================================+
 * |                                                                                             |
 * |                                Copyright (C) 2016-2018                                      |
 * |                                 Nomura Holdings, Inc.                                       |
 * |                                  All Rights Reserved                                        |
 * |                                                                                             |
 * |  This document is the sole property of Nomura Holdings, Inc.                                |
 * |  No part of this document may be reproduced in any form or by any                           |
 * |  means - electronic, mechanical, photocopying, recording or otherwise - without the prior   |
 * |  written permission of Nomura Holdings, Inc.                                                |
 * |                                                                                             |
 * |  Unless required by applicable law or agreed to in writing, software distributed under      |
 * |  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF        |
 * |  ANY KIND, either express or implied.                                                       |
 * |                                                                                             |
 * +=============================================================================================+
 */
package com.nri.dmm.msg.rule;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.base.Optional;
import com.nri.dmm.DmmConstants;
import com.nri.dmm.DmmException;
import com.nri.dmm.domain.entity.AccDocPurpose;
import com.nri.dmm.domain.entity.AccountDocPtcp;
import com.nri.dmm.domain.entity.AccountDocument;
import com.nri.dmm.domain.entity.AccountInfo;
import com.nri.dmm.domain.entity.DocumentType;
import com.nri.dmm.domain.entity.ServiceDocumentRole;
import com.nri.dmm.domain.entity.ServiceRule;
import com.nri.dmm.domain.service.AccDocPtcpService;
import com.nri.dmm.domain.service.AccDocPurposeService;
import com.nri.dmm.domain.service.AccDocService;
import com.nri.dmm.domain.service.DocumentTypeService;
import com.nri.dmm.domain.service.RuleMgmtService;
import com.nri.dmm.web.view.DocumentTypeSummaryView;
import com.nrift.finch.Globals;
import com.nrift.finch.inf.domain.entity.Branch;
import com.nrift.finch.inf.domain.service.ApplicationDateService;
import com.nrift.finch.inf.domain.service.BranchService;
import com.nrift.finch.inf.exception.FinchException;

/**
 * @author Sahayaruban This class used to execute the Rules and identify the documents
 */

public class RuleExecution {

	/**
	 * The <code>LOGGER</code> instance for this class
	 */
	private static final Logger		log								= LoggerFactory.getLogger(RuleExecution.class);

	/**
	 * RuleMgmtService
	 */
	@Autowired
	public RuleMgmtService			ruleMgmtService;

	/**
	 * AccDocPtcpService
	 */
	@Autowired
	public AccDocPtcpService		accDocPtcpService;

	/**
	 * DocumentTypeService
	 */
	@Autowired
	public DocumentTypeService		docTypeService;

	/**
	 * AccDocService
	 */
	@Autowired
	public AccDocService			accDocService;

	/**
	 * BranchService
	 */
	@Autowired
	private BranchService			branchService;

	/**
	 * ApplicationDateService
	 */
	@Autowired
	private ApplicationDateService	appDateService;
	
	/**
	 * AccDocPurposeService
	 */
	@Autowired
	private AccDocPurposeService	accDocPurService;

	/**
	 * Flag to identify if the document record needs to be reset or not
	 */
	private boolean					resetFlag						= false;

	/**
	 * Insert Document List
	 */
	private Set<Long>				newDocSet						= new HashSet<Long>();

	/**
	 * Removal Document list
	 */
	private List<AccountDocPtcp>	removalDocList					= new ArrayList<AccountDocPtcp>();

	/**
	 * Update Document list
	 */
	private List<AccountDocPtcp>	updateDocList					= new ArrayList<AccountDocPtcp>();

	/**
	 * Reset Document list for Approval RequiredFlag With Yes
	 */
	private List<AccountDocPtcp>	resetDocListForApproveReqYes	= new ArrayList<AccountDocPtcp>();

	/**
	 * PurposePk list for the waterfall documents
	 */
	private Set<Long>				purposePkSet					= new HashSet<Long>();

	/**
	 * Waterfall document list
	 */
	private List<AccountDocPtcp>	waterfallDocList				= new ArrayList<AccountDocPtcp>();

	/**
	 * Reset Document list for Approval RequiredFlag With No
	 */
	private List<AccountDocPtcp>	resetDocListForApproveReqNo		= new ArrayList<AccountDocPtcp>();
	
	/**
	 * serviceDocPkMap
	 */
	private Map<Long,String> serviceDocPkMap = new HashMap<Long,String>();
	
	/**
	 * Used to perform the rule execution operation
	 * 
	 * @param classificationPk
	 * @param branchPk
	 * @param entityTypePks
	 * @param capacity
	 * @param countryCode
	 * @param productPks
	 * @param accInfo
	 * @throws DmmException
	 * @throws FinchException
	 */
	public void performRuleExecution(Long classificationPk, Long branchPk, List<Long> entityTypePks, String capacity, String countryCode,
			List<Long> productPks, AccountInfo accInfo, boolean resetFlag) throws DmmException, FinchException {
		List<AccountDocPtcp> accountDocList = new ArrayList<AccountDocPtcp>();
		removalDocList.clear();
		updateDocList.clear();
		resetDocListForApproveReqYes.clear();
		resetDocListForApproveReqNo.clear();
		List<ServiceRule> serviceListForMsg = getServiceList(classificationPk, branchPk, entityTypePks, capacity, countryCode, productPks);
		serviceDocPkMap = getDocsFromService(serviceListForMsg);
		this.resetFlag = resetFlag;
		accountDocList = getAccountDocuments(accInfo);
		compareDocuments(serviceDocPkMap, accountDocList);
		update(updateDocList, accInfo);
		reset(resetDocListForApproveReqYes, accInfo, Globals.DATABASE_YES);
		reset(resetDocListForApproveReqNo, accInfo, Globals.DATABASE_NO);
		store(newDocSet, accInfo, countryCode);
		cancel(removalDocList, accInfo);
	}

	/**
	 * Used to get the list of services for an account
	 * 
	 * @param classificationPk
	 * @param branchPk
	 * @param entityType
	 * @param capacity
	 * @param countryCode
	 * @param productPks
	 * @return List
	 * @throws DmmException
	 * @throws FinchException
	 */
	public List<ServiceRule> getServiceList(Long classificationPk, Long branchPk, List<Long> entityType, String capacity, String countryCode,
			List<Long> productPks) throws DmmException, FinchException {
		List<ServiceRule> serviceRules = new ArrayList<ServiceRule>();
		serviceRules.addAll(getClassificationRule(classificationPk, branchPk));
		if (null != branchPk) {
			Branch branchRecord = branchService.getBranch(branchPk);
			if (branchRecord != null && null != branchRecord.getEnterprise() && !branchRecord.getEnterprise().getEnterpriseId().equals(countryCode)) {
				serviceRules.addAll(getCountryRule(countryCode, branchPk));
			}
		}
		serviceRules.addAll(getEntityRule(entityType));
		serviceRules.addAll(getCapacityRule(capacity));
		serviceRules.addAll(getProductRule(productPks));
		return serviceRules;
	}

	/**
	 * Used to get the document list related to a given account
	 * 
	 * @param accInfo
	 * @return List
	 */
	public List<AccountDocPtcp> getAccountDocuments(AccountInfo accInfo) throws DmmException {
		Long accInfopk = accInfo.getAccountInfoPk();
		List<AccountDocPtcp> accDoclist = accDocPtcpService.findDocListByPk(accInfopk);
		return accDoclist;
	}

	/**
	 * Used to add/update/remove the document records
	 * 
	 * @param serviceDocPkList
	 * @param accountDocList
	 * @throws DmmException
	 */
	public void compareDocuments(Map<Long,String> serviceDocPkMap, List<AccountDocPtcp> accountDocList) throws DmmException {
		List<Long> existingDocPkList = new ArrayList<Long>();
		Set<AccDocPurpose> accDocPurpose = new HashSet<AccDocPurpose>();
		/*
		 * Identify the existing ACTIVE Account documents whose Account Document purpose is NORMAL
		 * and get those document purpose and add it to addPurposePk
		 */
		for (AccountDocPtcp accountDocPtcp : accountDocList) {
			if (null != accountDocPtcp.getDmmAccountDocument()
					&& DmmConstants.ACTIVE.equals(accountDocPtcp.getDmmAccountDocument().getDocumentStatus())
					&& null != accountDocPtcp.getDmmAccountDocument().getDmmAccDocPurpose()) {
				accDocPurpose = accountDocPtcp.getDmmAccountDocument().getDmmAccDocPurpose();
				for (AccDocPurpose accountDocPurpose : accDocPurpose) {
					if (Globals.NORMAL_STATUS.equals(accountDocPurpose.getStatus())) {
						addPurposePk(accountDocPurpose.getDmmDocumentPurpose().getDocumentPurposePk());
					}
				}
			}
		}
		Set<Long> serviceDocPkSet = new HashSet<Long>();
		for (AccountDocPtcp accountDocPtcp : accountDocList) {
			/*
			 * Identify the existing NON ACTIVE Account documents purpose and compare with existing
			 * ACTIVE (or) Waterfall document purpose, If any document found cancel those documents
			 */
			if (null != accountDocPtcp.getDmmAccountDocument() && StringUtils.isEmpty(accountDocPtcp.getInheritedFlag())
					&& !DmmConstants.ACTIVE.equals(accountDocPtcp.getDmmAccountDocument().getDocumentStatus())
					&& null != accountDocPtcp.getDmmAccountDocument().getDmmAccDocPurpose()
					&& !accountDocPtcp.getDmmAccountDocument().getDmmAccDocPurpose().isEmpty()) {
				accDocPurpose = accountDocPtcp.getDmmAccountDocument().getDmmAccDocPurpose();
				boolean isSatisfied = true;
				boolean isNormalExist = false;
				for (AccDocPurpose accDocPurposeObj : accDocPurpose) {
					if (Globals.NORMAL_STATUS.equals(accDocPurposeObj.getStatus())) {
						isNormalExist = true;
						if (!purposePkSet.contains(accDocPurposeObj.getDmmDocumentPurpose().getDocumentPurposePk())) {
							isSatisfied = false;
							break;
						}
					}
				}
				if (isSatisfied && isNormalExist) {
					removalDocList.add(accountDocPtcp);
					continue;
				}
			}
			/*
			 * Identify the existing outstanding document for an account which are available in
			 * waterfall document Cancel those Outstanding document as these document satisfy by
			 * waterfall document
			 */
			for (AccountDocPtcp waterfallAccDocPtcp : waterfallDocList) {
				if (waterfallAccDocPtcp.getDmmAccountDocument().getDmmDocumentType().getDocumentTypePk()
						.equals(accountDocPtcp.getDmmAccountDocument().getDmmDocumentType().getDocumentTypePk())) {
					if ((DmmConstants.OUTSTANDING.equals(accountDocPtcp.getDmmAccountDocument().getActionId()) || DmmConstants.DELETED
							.equals(accountDocPtcp.getDmmAccountDocument().getActionId())) && StringUtils.isEmpty(accountDocPtcp.getInheritedFlag())) {
						removalDocList.add(accountDocPtcp);
					}
				}

			}

			serviceDocPkSet = serviceDocPkMap.keySet();
			if (!serviceDocPkSet.contains(accountDocPtcp.getDmmAccountDocument().getDmmDocumentType().getDocumentTypePk())) {
				if ((DmmConstants.OUTSTANDING.equals(accountDocPtcp.getDmmAccountDocument().getActionId()) || DmmConstants.DELETED
						.equals(accountDocPtcp.getDmmAccountDocument().getActionId())) && StringUtils.isEmpty(accountDocPtcp.getInheritedFlag())) {
					removalDocList.add(accountDocPtcp);
				} else {
					if (resetFlag && null == accountDocPtcp.getInheritedFlag()
							&& !DmmConstants.ACTIVE.equals(accountDocPtcp.getDmmAccountDocument().getDocumentStatus())
							&& !DmmConstants.EXPIRED.equals(accountDocPtcp.getDmmAccountDocument().getDocumentStatus())
							&& !DmmConstants.UPLOAD_OVERRIDE.equals(accountDocPtcp.getDmmAccountDocument().getActionId())
							&& !DmmConstants.EXTENDED.equals(accountDocPtcp.getDmmAccountDocument().getActionId())
							&& !(DmmConstants.RECEIVED.equals(accountDocPtcp.getDmmAccountDocument().getActionId()) 
									&& DmmConstants.PENDING.equals(accountDocPtcp.getDmmAccountDocument().getDocumentApprovedStatus()))) { 
						resetDocListForApproveReqNo.add(accountDocPtcp);
					} else if (null == accountDocPtcp.getInheritedFlag()
							&& Globals.DATABASE_YES.equals(accountDocPtcp.getDmmAccountDocument().getApprovalRequiredFlag())) {
						updateDocList.add(accountDocPtcp);
					}
				}
			} else {
				existingDocPkList.add(accountDocPtcp.getDmmAccountDocument().getDmmDocumentType().getDocumentTypePk());
				if (resetFlag && null == accountDocPtcp.getInheritedFlag()
						&& !DmmConstants.ACTIVE.equals(accountDocPtcp.getDmmAccountDocument().getDocumentStatus())
						&& !DmmConstants.UPLOAD_OVERRIDE.equals(accountDocPtcp.getDmmAccountDocument().getActionId()) 
						&& !DmmConstants.EXTENDED.equals(accountDocPtcp.getDmmAccountDocument().getActionId())
						&& !(DmmConstants.RECEIVED.equals(accountDocPtcp.getDmmAccountDocument().getActionId()) 
								&& DmmConstants.PENDING.equals(accountDocPtcp.getDmmAccountDocument().getDocumentApprovedStatus()))) { 
					resetDocListForApproveReqYes.add(accountDocPtcp);
				} else if (null == accountDocPtcp.getInheritedFlag()
						&& Globals.DATABASE_NO.equals(accountDocPtcp.getDmmAccountDocument().getApprovalRequiredFlag())) {
					updateDocList.add(accountDocPtcp);
				}
			}
		}
		newDocSet = serviceDocPkSet;
		for (Long existingDocPk : existingDocPkList) {
			newDocSet.remove(existingDocPk);
		}

		List<Long> purposeExistList = new ArrayList<Long>();
		for (Long newDocTypePk : newDocSet) {
			DocumentType documentType = docTypeService.findDocTypeByPk(newDocTypePk);
			if (null != documentType && null != documentType.getDmmDocumentPurpose()) {
				Long documentPurposePk = documentType.getDmmDocumentPurpose().getDocumentPurposePk();
				if (purposePkSet.contains(documentPurposePk)) {
					purposeExistList.add(newDocTypePk);
				}
			}
		}
		for (AccountDocPtcp accountDocPtcp : waterfallDocList) {
			if (null != accountDocPtcp.getDmmAccountDocument() && null != accountDocPtcp.getDmmAccountDocument().getDmmDocumentType()) {
				newDocSet.remove(accountDocPtcp.getDmmAccountDocument().getDmmDocumentType().getDocumentTypePk());
			}

		}
		newDocSet.removeAll(purposeExistList);
	}

	/**
	 * Used to store the document records
	 * 
	 * @param newDocList
	 * @param accInfo
	 * @throws DmmException
	 */
	public void store(Set<Long> newDocList, AccountInfo accInfo, String countryCode) throws DmmException {
		Set<AccountDocPtcp> dmmAccountDocPtcpsForAccountInfoPk = new HashSet<AccountDocPtcp>();
		if (null != accInfo && null != accInfo.getDmmAccountDocPtcpsForAccountInfoPk()) {
			dmmAccountDocPtcpsForAccountInfoPk = accInfo.getDmmAccountDocPtcpsForAccountInfoPk();
		}
		AccountDocument accountDocument = null;
		AccountDocPtcp accountDocPtcp = null;
		for (Long docTypePk : newDocList) {
			boolean isRequired = false;
			//Document Type with Document Requirement as ONCE_FIRST
			if(DmmConstants.ONCE_FIRST.equals(serviceDocPkMap.get(docTypePk))) {
				if(null != accInfo && null != docTypePk) {
					isRequired = accDocPtcpService.isDocumentRequiredOnce(accInfo.getAccountInfoPk(), docTypePk);
				}
			} else { //Document Type with Document Requirement other than ONCE_FIRST
				isRequired = true;
			}
			if(isRequired) {
				accountDocument = getNewAccountDocument(docTypePk, countryCode, accInfo.getOpenDate());
				accountDocPtcp = new AccountDocPtcp();
				accountDocPtcp.setDmmAccountInfoByAccountInfoPk(accInfo);
				accountDocPtcp.setDmmAccountDocument(accountDocument);
				accountDocPtcp.setStatus(Globals.NORMAL_STATUS);
				dmmAccountDocPtcpsForAccountInfoPk.add(accountDocPtcp);
			}
		}
		accInfo.setDmmAccountDocPtcpsForAccountInfoPk(dmmAccountDocPtcpsForAccountInfoPk);
	}

	/**
	 * Used to cancel the document records
	 * 
	 * @param removalDocList
	 * @param accInfo
	 * @throws DmmException
	 */
	public void cancel(List<AccountDocPtcp> removalDocList, AccountInfo accInfo) throws DmmException {
		Set<AccountDocPtcp> dmmAccountDocPtcpsForAccountInfoPk = new HashSet<AccountDocPtcp>();
		if (null != accInfo && null != accInfo.getDmmAccountDocPtcpsForAccountInfoPk()) {
			dmmAccountDocPtcpsForAccountInfoPk = accInfo.getDmmAccountDocPtcpsForAccountInfoPk();
			for (AccountDocPtcp accountDocPtcp : removalDocList) {
				accountDocPtcp.getDmmAccountDocument().setStatus(Globals.CANCEL_STATUS);
				dmmAccountDocPtcpsForAccountInfoPk.add(accountDocPtcp);
			}
			accInfo.setDmmAccountDocPtcpsForAccountInfoPk(dmmAccountDocPtcpsForAccountInfoPk);
		}
	}

	/**
	 * Used to cancel the document records
	 * 
	 * @param removalDocList
	 * @param accInfo
	 * @throws DmmException
	 */
	public void update(List<AccountDocPtcp> updateDocList, AccountInfo accInfo) throws DmmException {
		Set<AccountDocPtcp> dmmAccountDocPtcpsForAccountInfoPk = new HashSet<AccountDocPtcp>();
		if (null != accInfo && null != accInfo.getDmmAccountDocPtcpsForAccountInfoPk()) {
			dmmAccountDocPtcpsForAccountInfoPk = accInfo.getDmmAccountDocPtcpsForAccountInfoPk();
			for (AccountDocPtcp accountDocPtcp : updateDocList) {
				if (Globals.DATABASE_YES.equals(accountDocPtcp.getDmmAccountDocument().getApprovalRequiredFlag())) {
					accountDocPtcp.getDmmAccountDocument().setApprovalRequiredFlag(Globals.DATABASE_NO);
				}
				else if (Globals.DATABASE_NO.equals(accountDocPtcp.getDmmAccountDocument().getApprovalRequiredFlag())) {
					accountDocPtcp.getDmmAccountDocument().setApprovalRequiredFlag(Globals.DATABASE_YES);
				}
				dmmAccountDocPtcpsForAccountInfoPk.add(accountDocPtcp);
			}
			accInfo.setDmmAccountDocPtcpsForAccountInfoPk(dmmAccountDocPtcpsForAccountInfoPk);
		}
	}

	/**
	 * Used to reset the document records
	 * 
	 * @param removalDocList
	 * @param accInfo
	 * @throws FinchException 
	 */
	public void reset(List<AccountDocPtcp> resetDocList, AccountInfo accInfo, String approvedReqFlag) throws FinchException {
		Set<AccountDocPtcp> dmmAccountDocPtcpsForAccountInfoPk = new HashSet<AccountDocPtcp>();
		if (null != accInfo && null != accInfo.getDmmAccountDocPtcpsForAccountInfoPk()) {
			dmmAccountDocPtcpsForAccountInfoPk = accInfo.getDmmAccountDocPtcpsForAccountInfoPk();
			Date openDate = accInfo.getOpenDate();
			Date applnDate = appDateService.getApplicationDate(DmmConstants.COMPONENT_ID);
			AccountDocument accDoc = null;
			for (AccountDocPtcp accountDocPtcp : resetDocList) {
				accDoc = accountDocPtcp.getDmmAccountDocument();
				Integer gracePeriod = null;
				Date dueDate = null;
				DocumentType docTypeObj = accDoc.getDmmDocumentType();
				DocumentTypeSummaryView docTypeRuleInfo = docTypeService.findDocRuleInfo(docTypeObj.getMnemonic(), accInfo.getDmmCountry()
						.getCountryCode());
				gracePeriod = docTypeRuleInfo.getGracePeriod();
				if (null != gracePeriod) {
					if (gracePeriod == 0) {
						accDoc.setDocumentStatus(DmmConstants.STATUS_MISSING);
						accDoc.setDueDate(openDate);
					} else {
						dueDate = org.apache.commons.lang3.time.DateUtils.addDays(openDate, gracePeriod);
						if(dueDate.compareTo(applnDate) < 0){
							accDoc.setDocumentStatus(DmmConstants.GRACE_PERIOD_ENDED);
						} else {
							accDoc.setDocumentStatus(null);
						}
						accDoc.setDueDate(dueDate);
					}
				}
				// Document Type pk
				accDoc.setDmmDocumentType(docTypeObj);
				// Action Id
				accDoc.setActionId(DmmConstants.OUTSTANDING);
				// ApprovalRequiredFlag
				accDoc.setApprovalRequiredFlag(approvedReqFlag);
				// UploadedFlag
				accDoc.setUploadedFlag(Globals.DATABASE_NO);
				// KycFlag
				accDoc.setKycFlag(Globals.DATABASE_NO);
				// WaterfallFlag
				accDoc.setWaterfallFlag(Globals.DATABASE_NO);
				// Upload Required Flag
				accDoc.setUploadRequiredFlag(docTypeRuleInfo.getUploadReqd());
				// DataSource
				accDoc.setDataSource(DmmConstants.COMPONENT_ID);
				// RequestedDate
				accDoc.setRequestedDate(openDate);
				// Status
				accDoc.setStatus(Globals.NORMAL_STATUS);
				// Document Approved Status
				accDoc.setDocumentApprovedStatus(null);
				// Agreement Date
				accDoc.setAgreementDate(null);
				// Extension Date
				accDoc.setExtensionDate(null);
				// Expiry Date
				accDoc.setExpiryDate(null);
				// Document Execution Date
				accDoc.setDocumentExecutionDate(null);
				// Document Storage path
				accDoc.setDocumentStoragePath(null);
				// Followed By
				accDoc.setFollowedBy(null);
				//Note
				accDoc.setNote(null);
				//received date
				accDoc.setReceivedDate(null);
				accDocService.saveDmmAccountDocument(accDoc);

				dmmAccountDocPtcpsForAccountInfoPk.add(accountDocPtcp);
			}
			accInfo.setDmmAccountDocPtcpsForAccountInfoPk(dmmAccountDocPtcpsForAccountInfoPk);
		}
	}

	/**
	 * Used to get the Account document information and store it in the Database
	 * 
	 * @param docTypePk
	 * @return
	 * @throws DmmException
	 */
	private AccountDocument getNewAccountDocument(Long docTypePk, String countryCode, Date openDate) throws DmmException {
		try {
			Integer gracePeriod = null;
			AccountDocument accDoc = new AccountDocument();
			Date dueDate = null;
			Date applnDate = appDateService.getApplicationDate(DmmConstants.COMPONENT_ID);
			DocumentType docTypeObj = docTypeService.findDocTypeByPk(docTypePk);
			if (docTypeObj != null) {
				DocumentTypeSummaryView docTypeRuleInfo = docTypeService.findDocRuleInfo(docTypeObj.getMnemonic(), countryCode);
				gracePeriod = docTypeRuleInfo.getGracePeriod();
				if (null != openDate && null != gracePeriod) {
					if (gracePeriod == 0) {
						accDoc.setDocumentStatus(DmmConstants.STATUS_MISSING);
						accDoc.setDueDate(openDate);
					} else {
						dueDate = org.apache.commons.lang3.time.DateUtils.addDays(openDate, gracePeriod);
						if(dueDate.compareTo(applnDate) < 0){
							accDoc.setDocumentStatus(DmmConstants.GRACE_PERIOD_ENDED);
						}
						accDoc.setDueDate(dueDate);
					}
				}
				// Document Type pk
				accDoc.setDmmDocumentType(docTypeObj);
				// Action Id
				accDoc.setActionId(DmmConstants.OUTSTANDING);
				// ApprovalRequiredFlag
				accDoc.setApprovalRequiredFlag(Globals.DATABASE_YES);
				// UploadedFlag
				accDoc.setUploadedFlag(Globals.DATABASE_NO);
				// KycFlag
				accDoc.setKycFlag(Globals.DATABASE_NO);
				// WaterfallFlag
				accDoc.setWaterfallFlag(Globals.DATABASE_NO);
				// Upload Required Flag
				accDoc.setUploadRequiredFlag(docTypeRuleInfo.getUploadReqd());
				// DataSource
				accDoc.setDataSource(DmmConstants.COMPONENT_ID);
				// RequestedDate
				accDoc.setRequestedDate(openDate);
				// Status
				accDoc.setStatus(Globals.NORMAL_STATUS);
				// Document Reference No (Document Id)
				accDoc.setDocumentReferenceNo(accDocService.getNextDocId());

				accDocService.saveDmmAccountDocument(accDoc);
				storeDocPurpose(accDoc);
			}
			return accDoc;
		}
		catch (DmmException e) {
			throw e;
		}
		catch (Exception e) {
			log.error("Exception occured while stroing the data in database", e);
			throw new DmmException("rule.execution.error.data.persist", e);
		}
		catch (Throwable th) {
			log.error("Error occuerd while stroing the data in database", th);
			throw new DmmException("rule.execution.error.data.persist", th);
		}
	}

	/**
	 * Used to get the Services for the given Classification & Branch
	 * 
	 * @param classificationPk
	 * @param branchPk
	 * @return List
	 * @throws DmmException
	 */

	private List<ServiceRule> getClassificationRule(Long classificationPk, Long branchPk) throws DmmException {
		List<ServiceRule> clslist = new ArrayList<ServiceRule>();
		if (null != classificationPk) {
			Optional<ServiceRule> classRule = ruleMgmtService.findClassificationRule(DmmConstants.CLASSIFICATION_RULE, branchPk, classificationPk);
			if (classRule.isPresent()) {
				clslist.add(classRule.get());
			}
		}
		return clslist;
	}

	/**
	 * Used to get the Services for the given Countrycode
	 * 
	 * @param countryCode
	 * @return List
	 * @throws DmmException
	 */

	private List<ServiceRule> getCountryRule(String countryCode, Long branchPk) throws DmmException {
		List<ServiceRule> countrylist = new ArrayList<ServiceRule>();
		Optional<ServiceRule> countryRuleForEntity = ruleMgmtService.findCountryRuleForEntity(DmmConstants.COUNTRY_RULE, countryCode, branchPk);
		if (countryRuleForEntity.isPresent()) {
			countrylist.add(countryRuleForEntity.get());
		}
		else
		{
			Optional<ServiceRule> countryRule = ruleMgmtService.findCountryRuleForEntity(DmmConstants.COUNTRY_RULE, countryCode, null);
			if (countryRule.isPresent()) {
				countrylist.add(countryRule.get());
			}
			
		}
		Optional<ServiceRule> defaultCountryRule = ruleMgmtService.findCountryRule(DmmConstants.COUNTRY_RULE, null);
		if (defaultCountryRule.isPresent()) {
			countrylist.add(defaultCountryRule.get());
		}
		return countrylist;
	}

	/**
	 * Used to get the Services for the given Entity type
	 * 
	 * @param entityTypeList
	 * @return
	 * @throws DmmException
	 */
	private List<ServiceRule> getEntityRule(List<Long> entityTypeList) throws DmmException {
		List<ServiceRule> entitylist = new ArrayList<ServiceRule>();
		if (null != entityTypeList && entityTypeList.size() != 0) {
			for (Long entityPks : entityTypeList) {
				Optional<ServiceRule> entityCashRule = ruleMgmtService.findEntityTypeRule(DmmConstants.ENTITY_TYPE_RULE, entityPks);
				if (entityCashRule.isPresent()) {
					entitylist.add(entityCashRule.get());
				}

			}
		}
		return entitylist;
	}

	/**
	 * Used to get the Services for the given Capacity
	 * 
	 * @param capacity
	 * @return
	 * @throws DmmException
	 */
	private List<ServiceRule> getCapacityRule(String capacity) throws DmmException {
		List<ServiceRule> capacitylist = new ArrayList<ServiceRule>();
		Optional<ServiceRule> capacityRule = ruleMgmtService.findCapacityRule(DmmConstants.CAPACITY_RULE, capacity);
		if (capacityRule.isPresent()) {
			capacitylist.add(capacityRule.get());
		}
		return capacitylist;
	}

	/**
	 * Used to get the Services for given Product
	 * 
	 * @param productList
	 * @return List
	 * @throws DmmException
	 */
	private List<ServiceRule> getProductRule(List<Long> productList) throws DmmException {
		List<ServiceRule> prodlist = new ArrayList<ServiceRule>();
		if (null != productList && productList.size() != 0) {
			for (Long ProdTypePk : productList) {
				Optional<ServiceRule> prodRule = ruleMgmtService.findProductRule(DmmConstants.PRODUCT_RULE, ProdTypePk);
				if (prodRule.isPresent()) {
					prodlist.add(prodRule.get());
				}
			}
		}
		return prodlist;
	}

	
	/**
	 * @param serviceListForMsg
	 * @return
	 * @throws DmmException
	 */
	private Map<Long,String> getDocsFromService(List<ServiceRule> serviceListForMsg) throws DmmException {
		Map<Long,String> docMap = new HashMap<Long,String>();
		for (ServiceRule serviceRule : serviceListForMsg) {
			List<ServiceDocumentRole> serviceRuleList = accDocService.getDocsFromServiceRule(serviceRule.getServicePk());
			for (ServiceDocumentRole serviceRuleObj : serviceRuleList) {
				docMap.put(serviceRuleObj.getDmmDocumentType().getDocumentTypePk(), serviceRuleObj.getDocumentRequirement());
			}
		}
		return docMap;
	}

	/**
	 * @return purposePkSet
	 */
	public Set<Long> getPurposePkSet() {
		return purposePkSet;
	}

	/**
	 * To add the pup
	 * 
	 * @param purposePk
	 */
	public void addPurposePk(Long purposePk) {
		purposePkSet.add(purposePk);
	}

	/**
	 * @return
	 */
	public List<AccountDocPtcp> getWaterfallDocList() {
		return waterfallDocList;
	}

	public void setWaterfallDocList(List<AccountDocPtcp> waterfallDocList) {
		this.waterfallDocList = waterfallDocList;
	}
	
	/**
	 * Method used to store the Account documents whose Document purpose is NOT NULL
	 * @param accDoc
	 * @throws DmmException
	 */
	public void storeDocPurpose(AccountDocument accDoc) throws DmmException {
		try {
			if (null != accDoc.getDmmDocumentType().getDmmDocumentPurpose()) {
				AccDocPurpose accDocPurpose = new AccDocPurpose();
				accDocPurpose.setDmmAccountDocument(accDoc);
				accDocPurpose.setDmmDocumentPurpose(accDoc.getDmmDocumentType().getDmmDocumentPurpose());
				accDocPurpose.setStatus(Globals.NORMAL_STATUS);
				accDocPurService.saveAccDocPurpose(accDocPurpose);
			}
		}
		catch (DmmException e) {
			throw new DmmException(e);
		}

	}
}
