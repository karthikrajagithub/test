/*
 * +=============================================================================================+
 * |                                                                                             |
 * |                                Copyright (C) 2016-2018                                      |
 * |                                 Nomura Holdings, Inc.                                       |
 * |                                  All Rights Reserved                                        |
 * |                                                                                             |
 * |  This document is the sole property of Nomura Holdings, Inc.                                |
 * |  No part of this document may be reproduced in any form or by any                           |
 * |  means - electronic, mechanical, photocopying, recording or otherwise - without the prior   |
 * |  written permission of Nomura Holdings, Inc.                                                |
 * |                                                                                             |
 * |  Unless required by applicable law or agreed to in writing, software distributed under      |
 * |  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF        |
 * |  ANY KIND, either express or implied.                                                       |
 * |                                                                                             |
 * +=============================================================================================+
 */

package com.nri.dmm.domain.service;

import java.util.List;

import com.nri.dmm.DmmException;
import com.nri.dmm.domain.entity.AccountDocPtcp;

/**
 * @author Sahayaruban 
 * This class used to get the data from DMM_ACCOUNT_DOC_PTCP by passing the
 * required parameters
 */

public interface AccDocPtcpService {
	/**
	 * Used to get the list of waterfall documents
	 * 
	 * @param accInfoPk
	 * @return
	 * @throws DmmException
	 */
	public List<AccountDocPtcp> findWaterfallDocs(Long accInfoPk) throws DmmException;

	/**
	 * Method to find the list of documents for an accounts
	 * 
	 * @param accInfoPk
	 * @return
	 * @throws DmmException
	 */
	public List<AccountDocPtcp> findDocListByPk(Long accInfoPk) throws DmmException;

	/**
	 * Method to find the list of documents to cancel for the existing LCP, CCP records
	 * 
	 * @param accInfoPk
	 * @param hierarchicalLevel
	 * @return
	 */
	public List<AccountDocPtcp> findDocsToCancel(Long accInfoPk, String hierarchicalLevel) throws DmmException;
	
	/**
	 * Method to find whether document should be added to the account or not
	 * @param accInfoPk
	 * @param documentTypePk
	 * @return
	 * @throws DmmException
	 */
	public boolean isDocumentRequiredOnce(Long accInfoPk, Long documentTypePk) throws DmmException;

}
