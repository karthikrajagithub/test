/*
 * +=============================================================================================+
 * |                                                                                             |
 * |                                Copyright (C) 2016-2018                                      |
 * |                                 Nomura Holdings, Inc.                                       |
 * |                                  All Rights Reserved                                        |
 * |                                                                                             |
 * |  This document is the sole property of Nomura Holdings, Inc.                                |
 * |  No part of this document may be reproduced in any form or by any                           |
 * |  means - electronic, mechanical, photocopying, recording or otherwise - without the prior   |
 * |  written permission of Nomura Holdings, Inc.                                                |
 * |                                                                                             |
 * |  Unless required by applicable law or agreed to in writing, software distributed under      |
 * |  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF        |
 * |  ANY KIND, either express or implied.                                                       |
 * |                                                                                             |
 * +=============================================================================================+
 */
package com.nri.dmm;

import java.io.Serializable;

import com.documentum.operations.IDfCheckinOperation;
import com.documentum.operations.IDfDeleteOperationInternal;

/**
 * @author Sridharan
 * 
 */
public class DmmConstants implements Serializable {

	private static final long	serialVersionUID					= 1L;

	// ref
	public static final String	ENTRY								= "entry";

	public static final String	AMENDMENT							= "amend";

	public static final String	CANCEL								= "cancel";

	public static final String	QUERY								= "query";

	public static final String	CONFIRMED							= "CONFIRMED";

	/**
	 * Number of sort fields required in Trade Query screen
	 */
	public static final int		NUM_SORT_FIELDS						= 8;

	public static final String	EXPIRY_FLAG							= "EXPIRY_FLAG";

	public static final String	OUTSTANDING							= "OUTSTANDING";

	public static final String	RECEIVED							= "RECEIVED";

	public static final String	DELETED								= "DELETED";

	public static final String	UPLOAD_OVERRIDE						= "UPLOAD_OVERRIDE";

	public static final String	EXTENDED							= "EXTENDED";

	public static final String	STATUS_MISSING						= "MISSING";

	public static final String	STATUS_ACTIVE						= "ACTIVE";

	/**
	 * Y
	 */
	public static final String	YES									= "Y";

	/**
	 * N
	 */
	public static final String	NO									= "N";

	/**
	 * CLASSIFICATION_RULE
	 */
	public static final String	CLASSIFICATION_RULE					= "CLASSIFICATION_RULE";

	/**
	 * COUNTRY_RULE
	 */
	public static final String	COUNTRY_RULE						= "COUNTRY_RULE";

	/**
	 * ENTITY_TYPE_RULE
	 */
	public static final String	ENTITY_TYPE_RULE					= "ENTITY_TYPE_RULE";

	/**
	 * PRODUCT_RULE
	 */
	public static final String	PRODUCT_RULE						= "PRODUCT_RULE";

	/**
	 * CAPACITY_RULE
	 */
	public static final String	CAPACITY_RULE						= "CAPACITY_RULE";

	/**
	 * TRADE_TYPE_RULE
	 */
	public static final String	TRADE_TYPE_RULE						= "TRADE_TYPE_RULE";

	/**
	 * Service rule Country
	 */
	public static final String	ALL									= "ALL";
	
	/**
	 * TODAY
	 */
	public static final String TODAY								= "TODAY";

	/**
	 * Document rule Country
	 */
	public static final String	OTHERS								= "OTHERS";

	/**
	 * Number of fields required RDM Message Processing
	 */
	/**
	 * CounterParty
	 */
	public static final String	CCP									= "CCP";

	/**
	 * Legal counter party
	 */
	public static final String	LCP									= "LCP";

	/**
	 * NEAMPIDTAC 
	 */
	public static final String	NEAMPIDTAC							= "NEAMPIDTAC";
	
	/**
	 * NEAMPIDORG 
	 */
	public static final String	NEAMPIDORG							= "NEAMPIDORG";
	
	/**
	 * Neam
	 */
	public static final String	NEAM								= "NEAM";

	/**
	 * Account
	 */
	public static final String	ACCOUNT								= "ACCOUNT";

	/**
	 * Organisation
	 */
	public static final String	ORGANISATION						= "ORGANISATION";

	/**
	 * Party
	 */
	public static final String	PARTY								= "PARTY";

	/**
	 * Legal
	 */
	public static final String	LEGAL								= "LEGAL";

	/**
	 * Obligor
	 */
	public static final String	OBLIGOR								= "OBLG";

	/**
	 * AGENC
	 */
	public static final String	AGENC								= "AGENC";

	/**
	 * AGENCY
	 */
	public static final String	AGENCY								= "AGENCY";

	/**
	 * OBA
	 */
	public static final String	OBA									= "OBA";

	/**
	 * Waterfall
	 */
	public static final String	WATERFALL							= "W";

	/**
	 * Account Tag
	 */
	public static final String	ACCOUNT_TAG							= "<Account id=";

	/**
	 * T_LEG
	 */
	public static final String	T_LEG								= "T_LEG";

	/**
	 * T_PARY
	 */
	public static final String	T_PTY								= "T_PTY";

	/**
	 * Country code US
	 */
	public static final String	US									= "US";

	/**
	 * Account Type
	 */
	public static final String	ACC_TYPE							= "TA";

	/**
	 * Open
	 */
	public static final String	OPEN								= "OPEN";

	/**
	 * Inactive
	 */
	public static final String	INACTIVE							= "INACTIVE";

	/**
	 * Restricted
	 */
	public static final String	RESTRICTED							= "RSSTC";
	
	/**
	 * REACTIVE
	 */
	public static final String	REACTIVE							= "REACT";
	
	/**
	 * UNRESTRICTED
	 */
	public static final String	UNRESTRICTED						= "URSTC";
	
	/**
	 * OPNDT
	 */
	public static final String	OPEN_DATE							= "OPNDT";

	/**
	 * COMPONENT_ID
	 */
	public static final String	COMPONENT_ID						= "DMM";

	/**
	 * APPROVED
	 */
	public static final String	APPROVED							= "APPROVED";

	/**
	 * EXPIRED
	 */
	public static final String	EXPIRED								= "EXPIRED";

	/**
	 * GRACE_PERIOD_ENDED
	 */
	public static final String	GRACE_PERIOD_ENDED					= "GRACE_PERIOD_ENDED";

	/**
	 * ACTIVE
	 */
	public static final String	ACTIVE								= "ACTIVE";

	/**
	 * CLOSED
	 */
	public static final String	CLOSED								= "CLOSED";

	/**
	 * PENDING
	 */
	public static final String	PENDING								= "PENDING";

	/**
	 * REJECTED
	 */
	public static final String	REJECTED							= "REJECTED";

	/**
	 * NORMAL
	 */
	public static final String	NORMAL								= "NORMAL";

	/**
	 * KYC_FLAG_VIEW
	 */
	public static final String	KYC_STATUS_VIEW						= "KYC_STATUS_VIEW";

	/**
	 * DOCUMENT_DELETE
	 */
	public static final String	DOCUMENT_DELETE						= "DOCUMENT_DELETE";

	/**
	 * DOCUMENT_DOWNLOAD
	 */
	public static final String	DOCUMENT_DOWNLOAD					= "DOCUMENT_DOWNLOAD";

	/**
	 * DOCUMENT_UPLOAD
	 */
	public static final String	DOCUMENT_UPLOAD						= "DOCUMENT_UPLOAD";

	/**
	 * DASHBOARD
	 */
	public static final String	DASHBOARD							= "dashboard";

	/**
	 * DATE_FORMAT
	 */
	public static final String	DATE_FORMAT							= "yyyy-MM-dd";

	/**
	 * DATE_TIME_FORMAT
	 */
	public static final String	DATE_TIME_FORMAT					= "yyyy-MM-dd HH:mm:ss";

	/**
	 * INHERIT_A
	 */
	public static final String	ASSOCIATION							= "A";

	/**
	 * COLON
	 */
	public static final String	COLON								= " : ";

	/**
	 * SYSTEM
	 */
	public static final String	SYSTEM								= "SYSTEM";

	/**
	 * DOCUMENTUM_FILE_SEPARATOR
	 */
	public static final String	DOCUMENTUM_FILE_SEPARATOR			= "/";

	/**
	 * COMMA_SEPARATOR
	 */
	public static final String	COMMA_SEPARATOR						= ", ";

	/**
	 * HYPEN_SEPARATOR
	 */
	public static final String	HYPEN_SEPARATOR						= " - ";

	/**
	 * DOCUMENTUM_VERSION_LABEL
	 */
	public static final String	DOCUMENTUM_VERSION_LABEL			= "CURRENT";

	/**
	 * DOCUMENTUM_DOC_UPDATE_VERSION
	 */
	public static final int		DOCUMENTUM_DOC_UPDATE_VERSION		= IDfCheckinOperation.NEXT_MINOR;

	/**
	 * DOCUMENTUM_DOC_DELETE_VERSION
	 */
	public static final int		DOCUMENTUM_DOC_DELETE_VERSION		= IDfDeleteOperationInternal.ALL_VERSIONS;

	/**
	 * NEAM_SUCCESS_STATUS
	 */
	public static final String	NEAM_SUCCESS_STATUS					= "success";

	/**
	 * NEAM_FAIL_STATUS
	 */
	public static final String	NEAM_FAIL_STATUS					= "fail";

	/**
	 * NEAM_INCOMPLETE_STATUS
	 */
	public static final String	NEAM_INCOMPLETE_STATUS				= "incomplete";

	/**
	 * NEAM_ID
	 */
	public static final String	NEAM_ID								= "NEAM Id";

	/**
	 * RDM_ID
	 */
	public static final String	RDM_ID								= "RDM Id";

	/**
	 * BOOKING_ENTITY
	 */
	public static final String	BOOKING_ENTITY						= "Booking Entity";

	/**
	 * CLASSIFICATION_CODE
	 */
	public static final String	CLASSIFICATION_CODE					= "Classification Code";

	/**
	 * OPERATIONAL_COUNTRY
	 */
	public static final String	OPERATIONAL_COUNTRY					= "Operational Country";
	
	/**
	 * CCP_ID
	 */
	public static final String	CCP_ID								= "CCP Id";
	
	/**
	 * LCP_ID
	 */
	public static final String	LCP_ID								= "LCP Id";

	/**
	 * DIRECTORY_PATH
	 */
	public static final String	DIRECTORY_PATH						= "directoryPath";
	
	/**
	 * Queue Id
	 */
	public static final String	QUEUE_ID							= "queueId";

	/**
	 * FILE_DATE_FORMAT
	 */
	public static final String	FILE_DATE_FORMAT					= "yyyyMMddhhmmssSSS";

	/**
	 * FILE_DATE_FORMAT
	 */
	public static final String	APPLICATION_DATE_FORMAT				= "yyyyMMdd";

	/**
	 * DATA_SEPERATOR
	 */
	public static final char	DATA_SEPERATOR						= '|';

	/**
	 * FILE_EXT_DAT
	 */
	public static final String	FILE_EXT_DAT						= ".dat";

	/**
	 * HEADER_DATE
	 */
	public static final String	HEADER_DATE							= "DATE:";

	/**
	 * FOOTER_COUNT
	 */
	public static final String	FOOTER_COUNT						= "COUNT:";

	/**
	 * RESTRICTION_REQUIRED_ACCOUNT
	 */
	public static final String	RESTRICTION_REQUIRED_ACCOUNT		= "AccountRestriction_";

	/**
	 * RESTRICTION_REQUIRED_ACCOUNT
	 */
	public static final String	RESTRICTION_REQUIRED_ORGANISATION	= "OrgRestriction_";

	/**
	 * IS_WORD
	 */
	public static final String	IS_WORD								= " is ";

	/**
	 * LINE_END
	 */
	public static final String	LINE_END							= "\n";

	/**
	 * DATE
	 */
	public static final String	DATE								= "DATE";

	/**
	 * ERROR
	 */
	public static final String	ERROR								= "ERROR";

	/**
	 * DATA_LEGAL
	 */
	public static final String	DATA_LEGAL							= "DATA_LEGAL";

	/**
	 * UNDERSCORE_SEPARATOR
	 */
	public static final String	UNDERSCORE_SEPARATOR				= "_";

	/**
	 * ServiceId
	 */
	public static final String	SERVICE_ID							= "serviceId";

	/**
	 * Run Date
	 */
	public static final String	RUN_DATE							= "runDate";

	/**
	 * Hierarchical
	 */
	public static final String	HIERARCHICAL						= "hierarchicalLevel";

	/**
	 * RDMId
	 */
	public static final String	RDMID								= "rdmId";

	/**
	 * Trade Violation Query Base URL
	 */
	public static final String	trdURL								= "/dmm/trdviolation/query";

	/**
	 * Input Feed Query Base URL
	 */
	public static final String	processMsgURL						= "/dmm/inputfeed/query";

	/**
	 * FILENAME
	 */
	public static final String	FILE_NAME							= "fileName";

	/**
	 * Inactive Tag
	 */
	public static final String	INACT								= "INACT";

	/**
	 * Closed Tag
	 */
	public static final String	CLSD								= "CLSD";

	/**
	 * VIOLATION_STATUS_CLEAR
	 */
	public static final String	VIOLATION_STATUS_CLEAR				= "CLEAR";

	/**
	 * VIOLATION
	 */
	public static final String	VIOLATION							= "VIOLATION";

	/**
	 * TAKARA_MSG_FORMAT
	 */
	public static final String	TAKARA_MSG_DATE_FORMAT				= "dd-MM-yyyy";

	/**
	 * RDM
	 */
	public static final String	RDM									= "RDM";

	/**
	 * Error Message Query Base URL
	 */
	public static final String	errMsgURL							= "/dmm/errormessage/query";

	/**
	 * ORGANISATION TAG
	 */
	public static final String	ORGANISATION_TAG					= "<Organisation id=";

	/**
	 * UNKNOWN
	 */
	public static final String	UNKNOWN								= "UNKNOWN";

	/**
	 * SKIP_MSG
	 */
	public static final String	SKIP_MSG							= "SKIP_MSG";
	
	/**
	 * IS
	 */
	public static final String	IS									= "IS";

	/**
	 * Report Date Format
	 */
	public static final String	REPORT_DATE_FORMAT					= "MM/dd/yyyy";

	/**
	 * Blank
	 */
	public static final String	BLANK								= "";

	/**
	 * PDF
	 */
	public static final String	PDF_FORMAT							= "pdf";

	/**
	 * PDF
	 */
	public static final String	PDF									= "PDF";

	/**
	 * CSV
	 */
	public static final String	CSV									= "CSV";

	/**
	 * DOCUMENT_APPROVED_STATUS
	 */
	public static final String	DOCUMENT_APPROVED_STATUS			= "Document Approved Status";

	/**
	 * UNAPPROVED
	 */
	public static final String	UNAPPROVED							= "UNAPPROVED";

	/**
	 * AFUTC_TRADE_CODE
	 */
	public static final String	AFUTC_TRADE_CODE					= "FUTC";

	/**
	 * AGSEM_TRADE_CODE
	 */
	public static final String	AGSEM_TRADE_CODE					= "GSET";

	/**
	 * AMRGN_TRADE_CODE
	 */
	public static final String	AMRGN_TRADE_CODE					= "MRGN";

	/**
	 * AMSFT_TRADE_CODE
	 */
	public static final String	AMSFT_TRADE_CODE					= "MSFT";

	/**
	 * AREPO_TRADE_CODE
	 */
	public static final String	AREPO_TRADE_CODE					= "REPO";

	/**
	 * ASECL_TRADE_CODE
	 */
	public static final String	ASECL_TRADE_CODE					= "SECL";

	/**
	 * ATRIP_TRADE_CODE
	 */
	public static final String	ATRIP_TRADE_CODE					= "TRIP";

	/**
	 * N/A
	 */
	public static final String	NA									= "N/A";

	/**
	 * XML_EXTENSION - .xml
	 */
	public static final String	XML_EXTENSION						= ".xml";

	/**
	 * Number 30
	 */
	public static final String	NUM_30								= "30";

	/**
	 * Number 10
	 */
	public static final int		NUM_10								= 10;

	/**
	 * ACD20OD
	 */
	public static final String	ACD20OD								= "ACD20OD";

	/**
	 * ACD30OD
	 */
	public static final String	ACD30OD								= "ACD30OD";

	/**
	 * ACMD30D
	 */
	public static final String	ACMD30D								= "ACMD30D";

	/**
	 * Number 90
	 */

	public static final String	NUM_90								= "90";

	/**
	 * AMLC_MNEMONIC_D9
	 */
	public static final String	AMLC_MNEMONIC_D9					= "D9";

	/**
	 * AMLC_MNEMONIC_DC
	 */
	public static final String	AMLC_MNEMONIC_DC					= "DC";

	/**
	 * IPOC30D_MNEMONIC
	 */
	public static final String	IPOC30D_MNEMONIC					= "E2";

	/**
	 * Number 88
	 */
	public static final String	NUM_88								= "88";

	/**
	 * Number 44
	 */
	public static final String	NUM_44								= "44";

	/**
	 * Number 87
	 */
	public static final String	NUM_87								= "87";

	/**
	 * Number 76
	 */
	public static final String	NUM_76								= "76";

	/**
	 * Number 04
	 */
	public static final String	NUM_04								= "04";

	/**
	 * Number 02
	 */
	public static final String	NUM_02								= "02";

	/**
	 * MNEMONIC_FT
	 */
	public static final String	MNEMONIC_FT							= "FT";

	/**
	 * MNEMONIC_A5
	 */
	public static final String	MNEMONIC_A5							= "A5";

	/**
	 * MNEMONIC_BA
	 */
	public static final String	MNEMONIC_BA							= "BA";
	
	/**
	 * MNEMONIC_E0
	 */
	public static final String	MNEMONIC_E0							= "E0";

	/**
	 * Missing
	 */

	public static final String	MISSING								= "Missing";

	/**
	 * Expiring
	 */

	public static final String	EXPIRING							= "Expiring";

	/**
	 * Day_Of_Expiration
	 */

	public static final String	DAY_OF_EXPIRATION					= "Day of Expiration";

	/**
	 * EXPIRED_NOT_RESTRICTED
	 */
	public static final String	EXPIRED_NOT_RESTRICTED				= "Expired but Not Restricted";

	/**
	 * AOPTS
	 */
	public static final String	AOPTS								= "AOPTS";

	/**
	 * AOPTS_TRADE_CODE
	 */
	public static final String	AOPTS_TRADE_CODE					= "OPTS";

	/**
	 * AQIBS
	 */
	public static final String	AQIBS								= "AQIBS";

	/**
	 * AQIBS_TRADE_CODE
	 */
	public static final String	AQIBS_TRADE_CODE					= "QIBS";

	/**
	 * AREGS
	 */
	public static final String	AREGS								= "AREGS";

	/**
	 * AREGS_TRADE_CODE
	 */
	public static final String	AREGS_TRADE_CODE					= "REGS";

	/**
	 * CAMEL_FILE_NAME
	 */
	public static final String	CAMEL_FILE_NAME						= "camelFileName";

	/**
	 * DOC_PROCESSING_ERROR
	 */
	public static final String	DOC_PROCESSING_ERROR				= "DOC_PROCESSING_ERROR";

	/**
	 * DAY_ZERO_DOC_MSG
	 */
	public static final String	DAY_ZERO_DOC_MSG					= "DayZeroDocMsg";
	
	/**
	 * ASS_PROCESSING_ERROR
	 */
	public static final String	ASS_PROCESSING_ERROR				= "ASS_PROCESSING_ERROR";
	
	/**
	 * DAY_ZERO_ASSO_MSG
	 */
	public static final String	DAY_ZERO_ASSO_MSG					= "DayZeroAssoMsg";
	
	/**
	 * BRANCH NSI
	 */
	public static final String	NSI									= "NSI";

	/**
	 * DFC_PROPERTIES_FILE
	 */
	public static final String	DFC_PROPERTIES_FILE					= "dfc.properties";

	/**
	 * ACCOUNT_PROCESSING_ERROR
	 */
	
	public static final String	ACCOUNT_PROCESSING_ERROR			= "ACCOUNT_PROCESSING_ERROR";

	/**
	 * ORG_PROCESSING_ERROR
	 */
	public static final String	ORG_PROCESSING_ERROR				= "ORG_PROCESSING_ERROR";
	
	/**
	 * SKIP_MESSAGE
	 */
	public static final String	SKIP_MESSAGE						= "SKIP_MESSAGE";

	/**
	 * COUNT
	 */
	public static final String	COUNT								= "COUNT";

	/**
	 * INVALID_BRANCH
	 */
	public static final String	INVALID_BRANCH						= "INVALID_BRANCH";
	
	/**
	 * BULK_UPLOAD
	 */
	public static final String	BULK_UPLOAD = "BULK_UPLOAD";
	
	/**
	 * PRINC
	 */
	public static final String PRINC                               = "PRINC";

	/**
	 * PRINCIPAL
	 */
	public static final String  PRINCIPAL                         = "PRINCIPAL";
	
	/**
	 * STATUS_UPDATE
	 */
	public static final String STATUS_UPDATE = "statusUpdate";
	
	/**
	 * Number 20
	 */
	public static final String NUM_20 								= "20";
	
	/**
	 * PARTY ROLE
	 */
	public static final String	PARTY_ROLE							= "PARTY</RoleType>";
	
	/**
	 * LEGAL ROLE
	 */
	public static final String	LEGAL_ROLE							= "LEGAL</RoleType>";
	
	/**
	 * ONCE_FIRST
	 */
	public static final String	ONCE_FIRST							= "ONCE_FIRST";
	
}
