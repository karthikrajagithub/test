package com.fileoperation;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
 

public class ProcessFile {
	//MAIN
	public static void main(String args[]) {
		
		//textToXls("change.log");
		xlsToXml("xlsfile.xls");
  
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private static void xlsToXml(String filename) {
		DocumentBuilderFactory icFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder icBuilder;
			
			
			
	        try {
	            icBuilder = icFactory.newDocumentBuilder();
	            Document doc = icBuilder.newDocument();
	            URL namespaceURL = new URL("http://www.w3.org/2001/XMLSchema-instance");
	            String namespace = "xmlns:xsi="+namespaceURL.toString();
	            Element mainRootElement = doc.createElementNS(namespace, "Root");
	            doc.appendChild(mainRootElement);
	 
	            // append child elements to root element
	            mainRootElement.appendChild(getCompany(doc, "1", "Paypal", "Payment", "1000"));
	            mainRootElement.appendChild(getCompany(doc, "2", "eBay", "Shopping", "2000"));
	            mainRootElement.appendChild(getCompany(doc, "3", "Google", "Search", "3000"));
	 
	            // output DOM XML to console 
	            Transformer transformer = TransformerFactory.newInstance().newTransformer();
	            transformer.setOutputProperty(OutputKeys.INDENT, "yes"); 
	            DOMSource source = new DOMSource(doc);
	            StreamResult console = new StreamResult(System.out);
	            StreamResult xfile = new StreamResult(new File("emps.xml"));
	            transformer.transform(source, console);
	            transformer.transform(source, xfile);
	 
	            System.out.println("\nXML DOM Created Successfully..");
	 
	        	
			
			/////////////////////////////////////////////////////////
            FileInputStream file = new FileInputStream(new File(filename));
 
            //Create Workbook instance holding reference to .xlsx file
            HSSFWorkbook  workbook = new HSSFWorkbook(file);
 
            //Get first/desired sheet from the workbook
            HSSFSheet sheet = workbook.getSheetAt(0);
 
            //Iterate through each rows one by one
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) 
            {
                Row row = rowIterator.next();
                //For each row, iterate through all the columns
                Iterator<Cell> cellIterator = row.cellIterator();
                 
                while (cellIterator.hasNext()) 
                {
                    Cell cell = cellIterator.next();
                    //Check the cell type and format accordingly
                    switch (cell.getCellType()) 
                    {
                        case Cell.CELL_TYPE_NUMERIC:
                            System.out.print(cell.getNumericCellValue() + "\t");
                            break;
                        case Cell.CELL_TYPE_STRING: 
                            System.out.print(cell.getStringCellValue() + "\t");
                            break;
                    }
                }
                
                
                System.out.println("");
            }
            file.close();
        
	} catch (Exception e) {
        e.printStackTrace();
    }
    
        }
		
	
    private static Node getCompany(Document doc, String id, String name, String age, String role) {
        Element company = doc.createElement("Row");
       // company.setAttribute("id", id);
        company.appendChild(getXLSElements(doc, company, "ColumnA", name));
        company.appendChild(getXLSElements(doc, company, "ColumnB", age));
        company.appendChild(getXLSElements(doc, company, "ColumnC", role));
        return company;
    }
 
    // utility method to create text node
    private static Node getXLSElements(Document doc, Element element, String name, String value) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }	
		
	
	
	
    //METHOD TO READ A DATA FROM TEXT FILE AND STORE THE PROCESSED DATA INTO THE XLS
	public static void textToXls(String filename)
	{
	BufferedReader br = null;

	try {

		String sCurrentLine;
		br = new BufferedReader(new FileReader(filename));

		int i = 0;
		ArrayList characters = new ArrayList();// big
																	
		while ((sCurrentLine = br.readLine()) != null) {
			String[] arr = sCurrentLine.split(" ");
			// for the first line it'll print
			/*System.out.print("arr[0] = " + arr[0]); // 1st row
			System.out.print("arr[1] = " + arr[1]); // 2nd row
			System.out.println("arr[2] = " + arr[2]); // 3rd row
*/			if (arr.length == 4) {
				System.out.println("arr[3] = " + arr[3]);
			}


			for (String nChar : arr) {
				characters.add(Integer.parseInt(nChar));
				// i++;

			}

		}
		xlsWrite("xlswrite.xls", characters);

	} 
	
	
	catch (IOException e) {
		e.printStackTrace();
	}
	
	
	finally {
		try {
			if (br != null)
				br.close();
		} 
		
		catch (IOException ex) {
			ex.printStackTrace();
		}

	}
}

	

  //METHOD TO WRITE A DATA INTO THE XLS FILE
	public static void xlsWrite(String filename, ArrayList characters) throws IOException {
		BufferedWriter outputWriter = null;
		outputWriter = new BufferedWriter(new FileWriter(filename));
		int c = 0;
		outputWriter.write("A\tB\tC\tSUM\tAVG\tMAX\tMIN");
		outputWriter.newLine();
		int[] temp = new int[3];

		for (int i = 0; i < characters.size(); i++) {
			// Maybe:
			outputWriter.write(characters.get(i) + "\t");
			System.out.println(characters.size());
			temp[c] = (int) characters.get(i);
			++c;
			
			if (c == 3) {
				int sum = doSum(temp);
				outputWriter.write(sum + "\t");
				
				int avg = doAvg(temp);
				outputWriter.write(avg + "\t");
				
				int max = findMax(temp);
				outputWriter.write(max + "\t");
				
				int min = findMin(temp);
				outputWriter.write(min + "\t");
				
				
				
				outputWriter.newLine();
				c = 0;
			}
		}
		outputWriter.flush();
		outputWriter.close();
	}
	
	
	
	
	//SUM METHOD
	
	public static int doSum(int[] arr) {
		int sum = 0;
		for (int i : arr) {
			sum = sum + i;
		}
		return sum;
	}
	
	
	
	//AVERAGE METHOD
	public static int doAvg(int[] arr) {
		int sum = 0;
		int c=0;
		for (int i : arr) {
			sum = sum + i;
			c++;
		}
		int avg=sum/c;
		return avg;
	}
	
	//METHOD TO FIND MAXIMUM NUMBER
	public static int findMax(int[] arr)
	{
	int largest = Integer.MIN_VALUE;
    
    for(int i =0;i<arr.length;i++) {
        if(arr[i] > largest) {
            largest = arr[i];
        }
    }
    return largest;
	
	}
	
	//METHOD TO FIND MIN NUMBER
	public static int findMin(int[] arr)
	{
	int smallest = Integer.MAX_VALUE;
    
    for(int i =0;i<arr.length;i++) {
        if(arr[i] < smallest) {
            smallest = arr[i];
        }
    }
    return smallest;
	
	}
	
	
}
