package com.fileoperation;

public class delet {

}
