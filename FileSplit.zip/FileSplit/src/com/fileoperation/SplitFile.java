package com.fileoperation;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.io.IOException;


public class SplitFile {



	public void splitCharsSimple(String f) throws IOException {

		FileInputStream instream = null;
		FileOutputStream outstream = null;
		int count=0,c=0;;
		try{
			File infile =new File(f);
			File outfile =new File("D:\\MyOutputFile.txt");

			instream = new FileInputStream(infile);
			outstream = new FileOutputStream(outfile);

			byte[] buffer = new byte[1];

			int length;

			while ((length = instream.read(buffer)) > 0){

				count++;
				//System.out.println(count);
				if(count==1000)
				{  

					//System.out.println(count);
					c++;
					outstream=new FileOutputStream(new File("D:\\MyOutputFile"+c+".txt"));
					count=0;
				}
				outstream.write(buffer, 0, length);

			}


			instream.close();
			outstream.close();

			

		}catch(IOException e){
			e.printStackTrace();
		}
		

	}
	}   




