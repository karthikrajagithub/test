package com.user;


import java.io.IOException;
import java.util.Scanner;

import com.fileoperation.SplitFile;

public class FileSplitProcess {

	public static void main(String[] args) throws IOException {
		
		Scanner in = new Scanner(System.in);
		
	//	SplitFile sf = new SplitFile();
		
	System.out.println("Enter the input :");
	String s=in.nextLine();
	
	
		
		//sf.splitCharsSimple("THIRDPARTYLICENSEREADME.txt");
		/*System.out.println("Enter the words to find and write it into another files :");
		String words = in.nextLine();
		*/
		boolean check = intOrNot(s);
		System.out.println(check);
		
//String s1="56";
	}
	
	static boolean intOrNot(String input)
	{  int s;
	    try
	    {
	       s= Integer.parseInt(input);
	       System.out.println(s);
	    }
	    catch(Exception ex)
	    {
	        return false;
	    }
	    return true;
	}

}
